#include <stdio.h>

int main(void)
{
	int nData = 10;
	printf("%s\n", "nData");

	printf("%d\n", nData);
	printf("%p\n", &nData);
	return 0;
}
