#include <stdio.h>

int main(void)
{
    int x = 0, nInput = 0;
    scanf_s("%d", &nInput);

    x = nInput;
    printf("%d\n", x);
	return 0;
}
