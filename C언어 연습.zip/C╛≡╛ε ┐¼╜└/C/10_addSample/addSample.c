#include <stdio.h>

int main(void)
{
    int nResult = 0;

    nResult = 3 + 4 - 5;
    printf("nResult : %d\n", nResult);
	return 0;
}
