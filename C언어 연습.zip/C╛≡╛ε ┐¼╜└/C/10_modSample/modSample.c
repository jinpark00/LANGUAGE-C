#include <stdio.h>

int main(void)
{
    int x = 0;
    scanf_s("%d", &x);

    printf("�� : %d\n", x / 3);
    printf("������ : %d\n", x % 3);

	return 0;
}
